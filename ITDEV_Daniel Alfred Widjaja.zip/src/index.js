import React from 'react';
import ReactDOM from 'react-dom';
import registerServiceWorker from './registerServiceWorker';

import CV from './CV';

ReactDOM.render(<CV/>,document.getElementById('root'));
registerServiceWorker();
